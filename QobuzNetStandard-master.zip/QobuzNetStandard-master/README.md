# QobuzNetStandard
Qobuz .NET Standard Library
This library is intentended to Call Qobuz REST APIs. Built in .NET Standard framework.

Work in Progress!!!
